import org.apache.log4j.Logger;

import java.util.*;


public class BasketShop implements Basket {

    private final Logger LOG = Logger.getLogger(BasketShop.class.getName());

    private Map<String, Product> map = new HashMap<>();


    @Override
    public void addProduct(String product, int quantity) {

        Product pr = new Product();

        if (map.containsKey(product)) {

            pr = map.get(product);
            pr.setQuantity(pr.getQuantity() + quantity);
            return;
        }
        pr.setName(product);
        pr.setQuantity(quantity);
        map.put(product, pr);
        LOG.info("Продукт " + pr.getName() + " добавлен в колличестве " + pr.getQuantity());
    }

    @Override
    public void removeProduct(String product) {

        if (map.containsKey(product)) {
            map.remove(product);
            LOG.info("Продукт удален ");
        } else {
            LOG.info("Такого продукта нет ");
        }

    }

    @Override
    public void updateProductQuantity(String product, int quantity) {

        if (map.containsKey(product)) {
            Product pr = map.get(product);
            pr.setQuantity(quantity);
            LOG.info("Колличество продукта " + pr.getName() + " изменено на " + pr.getQuantity());
        }

    }

    @Override
    public void clear() {
        map.clear();
        LOG.info("Корзина отчищина ");
    }

    @Override
    public List<String> getProducts() {
        LOG.info("Список товаров в корзине ");
        List<String> list = new ArrayList<>();
        for (Map.Entry<String, Product> m : map.entrySet()) {
            list.add(m.getValue().getName());
            LOG.info(m.getValue().getName());
        }

        return list;
    }

    @Override
    public int getProductQuantity(String product) {

        if (map.containsKey(product)) {
            Product pr = map.get(product);
            LOG.info(pr.getName() + " куплен в колличестве " + pr.getQuantity());
            return pr.getQuantity();
        }

        return -1;
    }
}
